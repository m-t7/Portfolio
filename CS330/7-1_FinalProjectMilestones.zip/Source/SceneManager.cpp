///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Gunmetal - matte dark steel
	OBJECT_MATERIAL gunmetalMaterial;
	gunmetalMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.12f);
	gunmetalMaterial.ambientStrength = 0.3f;
	gunmetalMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.22f);
	gunmetalMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	gunmetalMaterial.shininess = 4.0f;
	gunmetalMaterial.tag = "gunmetal";
	m_objectMaterials.push_back(gunmetalMaterial);

	// Mesh Filter - dark, soft, low-shine
	OBJECT_MATERIAL meshFilterMaterial;
	meshFilterMaterial.ambientColor = glm::vec3(0.05f, 0.05f, 0.05f);
	meshFilterMaterial.ambientStrength = 0.2f;
	meshFilterMaterial.diffuseColor = glm::vec3(0.15f, 0.15f, 0.15f);
	meshFilterMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	meshFilterMaterial.shininess = 0.0f;
	meshFilterMaterial.tag = "mesh_filter";
	m_objectMaterials.push_back(meshFilterMaterial); 

	// Wood - natural, low-gloss
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);  // Slight brown tint
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 8.0f;  // Slightly shinier wood
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL blackPlasticMaterial;
	blackPlasticMaterial.ambientColor = glm::vec3(0.02f, 0.02f, 0.02f);     // Very dark ambient base
	blackPlasticMaterial.ambientStrength = 0.2f;                            // Low ambient strength
	blackPlasticMaterial.diffuseColor = glm::vec3(0.1f, 0.1f, 0.1f);        // Dark gray diffuse to show form
	blackPlasticMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);       // Subtle specular to simulate light plastic shine
	blackPlasticMaterial.shininess = 8.0f;                                  // Low-to-moderate shininess
	blackPlasticMaterial.tag = "black_plastic";
	m_objectMaterials.push_back(blackPlasticMaterial);

	OBJECT_MATERIAL matteMousepadMaterial;
	matteMousepadMaterial.ambientColor = glm::vec3(0.05f, 0.05f, 0.05f);      // Slightly brighter ambient than plastic
	matteMousepadMaterial.ambientStrength = 0.3f;                             // Moderate ambient strength for soft appearance
	matteMousepadMaterial.diffuseColor = glm::vec3(0.12f, 0.12f, 0.12f);      // Dark gray diffuse for fabric look
	matteMousepadMaterial.specularColor = glm::vec3(0.01f, 0.01f, 0.01f);     // Nearly no specular � very matte
	matteMousepadMaterial.shininess = 2.0f;                                   // Very low shininess to kill reflections
	matteMousepadMaterial.tag = "matte_mousepad";
	m_objectMaterials.push_back(matteMousepadMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.02f, 0.02f, 0.02f);       // Very low ambient
	glassMaterial.ambientStrength = 0.1f;                              // Subtle ambient
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.4f, 0.45f);         // Very light blue-gray tint
	glassMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);         // Strong specular highlights
	glassMaterial.shininess = 128.0f;                                  // Very high shininess for sharp reflections
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);
}


/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Light Source 0 - Top-down soft white
	m_pShaderManager->setVec3Value("lightSources[0].position", 3.0f, 8.0f, -4.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.7f, 0.7f, 0.7f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.7f, 0.7f, 0.7f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.4f, 0.4f, 0.4f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 16.0f); // Not used in shader yet
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.1f);

	// In your SetupSceneLights() function:
	m_pShaderManager->setVec3Value("lightSources[2].position", 2.085f, 1.3f, -0.1f); // RAM 1
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.3f, 0.0f, 0.4f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.6f, 0.2f, 0.7f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.6f, 0.2f, 0.7f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.5f);

	// Light Source 3 - Bright lamp behind and above the PC
	m_pShaderManager->setVec3Value("lightSources[3].position", 7.0f, 6.0f, -6.0f); // X near PC, Y high, Z behind
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.7f, 0.7f, 0.5f); // Warm white/yellow
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.9f, 0.95f, 0.8f); // Bright
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 1.0f, 0.95f, 0.8f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 1.0f);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag, float transparency = 1.0f)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
		m_pShaderManager->setFloatValue("transparency", transparency);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/
	bool bReturn = false;

	bReturn = CreateGLTexture(
		"textures/BLACK_fILTER.jpg",
		"filter");
	
	bReturn = CreateGLTexture(
		"textures/stainless.jpg",
		"stainless");

	bReturn = CreateGLTexture(
		"textures/wood.jpg",
		"wood");

	bReturn = CreateGLTexture(
		"textures/asus.jpg",
		"asus");

	bReturn = CreateGLTexture(
		"textures/mat.png",
		"mat");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

// Represents a single keyboard key's properties including label, width, and color.
struct Key {
	std::string label;
	float widthUnits;
};

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	
	// define the materials that will be used for the objects  in the 3D scene
	DefineObjectMaterials();
	// add and defile the light sources for the 3D scene
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();

}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	DrawDesk();
	DrawMousepad();
	DrawKeyboard();
	DrawFormdT1Case();
	DrawMonitor();
	DrawMouse();
	DrawHeadphones();
	DrawGameController();
}

void SceneManager::DrawDesk() {
	glm::vec3 scaleXYZ(10.0f, 1.0f, 5.0f);
	glm::vec3 positionXYZ(0.0f, 0.0f, -2.0f);
	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderTexture("wood");  // Use wood texture for the desk
	SetTextureUVScale(6.0f, 4.0f); // Tile the wood texture for a more natural look
	SetShaderMaterial("wood"); // Use the defined wood material
	// Lighting and material handled by fragment shader, so no SetShaderMaterial or SetShaderColor here
	m_basicMeshes->DrawPlaneMesh();
}

// Draws a keyboard key using provided scale, rotation, position, and color.
void SceneManager::DrawKeyboardKey(glm::vec3 scale, float XrotationDegrees, float YrotationDegrees, float ZrotationDegrees, glm::vec3 position, glm::vec4 color)
{
	SetTransformations(scale, XrotationDegrees, YrotationDegrees, ZrotationDegrees, position);
	SetShaderColor(color.r, color.g, color.b, color.a);
	SetShaderMaterial("black_plastic"); // Use black plastic material
	m_basicMeshes->DrawBoxMesh();
}

void SceneManager::DrawKeyboard() 
{
	/****************************************************************/
	// Draw the base of the keyboard
	/****************************************************************/ 
	glm::vec3 scaleXYZ(6.0f, 0.2f, 2.75f);  // Wider and flat
	glm::vec3 positionXYZ(-1.75f, 0.2f, 0.5f);  // Slightly raised
	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderColor(0.08f, 0.08f, 0.08f, 1.0f);  // Dark color
	SetShaderMaterial("black_plastic"); // Use black plastic material 
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	// Draw main alphanumeric keys in a 5x14 grid
	/****************************************************************/

	float keyWidth = 0.3f;

	// Size XYZ scale for each key
	scaleXYZ = glm::vec3(keyWidth, 0.15f, 0.3f);
	
	// color for each ley
	glm::vec4 keyColor(0.01f, 0.01f, 0.01f, 1.0f);

	float startX = -4.65f + scaleXYZ.x;  // draw keys starting from left side of the board
	float startZ = -0.75f + scaleXYZ.z;  // draw keys starting from the top of the board
	float spacing = 0.4f;  // space between each key

	// fill each space on the keyboard (5x14 grid)
	for (int row = 0; row < 5; ++row) {
		for (int col = 0; col < 14; ++col) {
			positionXYZ = glm::vec3(startX + col * spacing, 0.3f, startZ + row * spacing);

			DrawKeyboardKey(scaleXYZ, 0, 0, 0, positionXYZ, keyColor);
		}
	}

	/****************************************************************/
	// Draw the bottom row with custom key widths
	/****************************************************************/

	std::vector<Key> bottomRow = {
		{"Ctrl",   1.25f},
		{"Win",    1.25f},
		{"Alt",    1.25f},
		{"Space",  6.0f},
		{"AltGr",  1.25f},
		{"Fn",     1.25f},
		{"Menu",   1.25f},
		{"Ctrl",   1.25f}
	};

	float currentX = startX;
	float zPos = 1.55f;
	spacing = 0.095f;

	for (const auto& key : bottomRow) {
		glm::vec3 scale = glm::vec3(key.widthUnits * keyWidth, 0.15f, 0.3f);
		glm::vec3 position = glm::vec3(currentX + scale.x / 2.0f, 0.3f, zPos);

		// All rotation angles are 0 for aligned keys
		DrawKeyboardKey(scale, 0, 0, 0, position, keyColor);

		currentX += scale.x + spacing;
	}
}

/***********************************************************
 *  DrawFormdT1Case()
 *
 *  This method is used for rendering the FORMD T1 PC case
 ***********************************************************/
void SceneManager::DrawFormdT1Case() {
	// Case body
	glm::vec3 caseScale(1.75f, 2.5f, 3.75f);
	glm::vec3 casePosition(8.0f, 1.3f, 0.0f);
	float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;
	SetTransformations(caseScale, XrotationDegrees, YrotationDegrees, ZrotationDegrees, casePosition);
	SetShaderTexture("stainless");
	SetShaderMaterial("gunmetal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Separator on the front
	glm::vec3 separatorScale(caseScale.x / 2.0f, 0.5f, 0.01f);
	glm::vec3 separatorPosition = casePosition + glm::vec3(0.0f, 0.4f, caseScale.z / 2.0f + separatorScale.z / 2.0f);
	XrotationDegrees = 90.0f;
	SetTransformations(separatorScale, XrotationDegrees, YrotationDegrees, ZrotationDegrees, separatorPosition);
	SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	m_basicMeshes->DrawPlaneMesh();

	// Dust filter mesh on the left
	glm::vec3 filterScale(0.008f, caseScale.y * 0.88f, caseScale.z * 0.93f);
	glm::vec3 filterPosition = casePosition + glm::vec3(-caseScale.x / 2.0f - filterScale.x / 2.0f - 0.01, 0.0f, 0.0f);
	SetTransformations(filterScale, 0.0f, 0.0f, 0.0f, filterPosition);
	SetShaderTexture("filter");
	SetTextureUVScale(3.0f, 3.0f);
	SetShaderMaterial("mesh_filter");
	m_basicMeshes->DrawBoxMesh();

	// Dust filter mesh on the right
	filterPosition = casePosition + glm::vec3(caseScale.x / 2.0f - filterScale.x / 2.0f + 0.01f, 0.0f, 0.0f);
	SetTransformations(filterScale, 0.0f, 0.0f, 0.0f, filterPosition);
	SetShaderTexture("filter");
	SetTextureUVScale(3.0f, 3.0f);
	SetShaderMaterial("mesh_filter");
	m_basicMeshes->DrawBoxMesh();

	// Ram on the right
	glm::vec3 ramScale(0.02f, 0.01f, 0.4f); // Thin, flat top
	glm::vec3 ramPosition = casePosition + glm::vec3(-caseScale.x / 2.0f - ramScale.x / 2.0f - 0.03f, 0.0f, 0.0f);
	SetTransformations(ramScale, 90.0f, 0.0f, 90.0f, ramPosition);
	SetShaderColor(0.6f, 0.2f, 0.7f, 0.5f); // Purple color
	m_basicMeshes->DrawPlaneMesh();
	
	// Ram on the left
	ramPosition.z -= 0.08f; // Move it to the left side
	SetTransformations(ramScale, 90.0f, 0.0f, 90.0f, ramPosition);
	m_basicMeshes->DrawPlaneMesh();

	// Draw glow plane (slightly bigger, transparent)
	glm::vec3 glowScale = ramScale + glm::vec3(0.25f, 0.0f, 0.4f); // Slightly larger in X and Z
	glm::vec3 glowPosition = ramPosition + glm::vec3(0.0f, -0.1f, 0.02f); // Same position
	SetTransformations(glowScale, 90.0f, 0.0f, 90.0f, glowPosition);
	SetShaderColor(0.6f, 0.2f, 0.7f, 0.2f); // Lighter purple, transparent
	m_basicMeshes->DrawPlaneMesh();
}

void SceneManager::DrawMousepad() {
	// Lighting and material handled by fragment shader, so no SetShaderMaterial or SetShaderColor here
	SetTransformations(glm::vec3(7.6f, 1.0f, 2.35f), 0, 0, 0, glm::vec3(-1.25f, 0.04f, 0.5f));
	SetShaderColor(0.4f, 0.4f, 0.6f, 1.0f); // Light blue color
	SetShaderMaterial("matte_mousepad"); // Use the defined wood material

	m_basicMeshes->DrawPlaneMesh();
	glm::vec3 scaleXYZ(7.5f, 1.0f, 2.3f);
	glm::vec3 positionXYZ(-1.2f, 0.05f, 0.5f);
	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f); // Dark gray color
	SetShaderMaterial("matte_mousepad"); // Use the defined wood material
	SetShaderTexture("mat");
	SetTextureUVScale(1.0f, 1.0f); // Scale texture to fit mousepad
	m_basicMeshes->DrawPlaneMesh();

}

void SceneManager::DrawMonitor() {
	// ----- draw monitor -----
	glm::vec3 monitorScale = glm::vec3(8.5f, 0.25f, 4.5f); // Wide and flat
	glm::vec3 monitorPosition = glm::vec3(-1.25f, 4.5f, -4.75f);
	SetTransformations(monitorScale, 90.0f, 0.0f, 0.0f, monitorPosition);
	SetShaderColor(0.01f, 0.01f, 0.01f, 1.0f); // Dark matte black
	SetShaderMaterial("black_plastic"); // Use black plastic material
	m_basicMeshes->DrawBoxMesh();

	// ----- Draw Screen (optional glow plane) -----
	glm::vec3 screenScale(8.4f, 0.001f, 4.3f); // Slightly smaller than monitor
	glm::vec3 screenPosition = monitorPosition + glm::vec3(0.0f, 0.051f, 0.13f); // Slightly in front
	SetTransformations(screenScale, 90.0f, 0.0f, 0.0f, screenPosition);
	SetShaderColor(0.1f, 0.1f, 0.15f, 1.0f); // Slightly lighter
	SetShaderMaterial("glass"); // Use black plastic material
	SetShaderTexture("asus");
	SetTextureUVScale(1.0f, 1.0f); // Scale texture to fit screen
	m_basicMeshes->DrawBoxMesh();

	// ----- Stand: Central Neck -----
	glm::vec3 neckScale = glm::vec3(0.25f, 1.7f, 0.1f); // Thicker, taller for big monitor
	glm::vec3 neckPosition = monitorPosition + glm::vec3(0.0f, -3.9f, 0.0f); // Drop down accordingly
	SetTransformations(neckScale, 0.0f, 0.0f, 0.0f, neckPosition);
	SetShaderMaterial("black_plastic");
	SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f); // Slight shine
	m_basicMeshes->DrawCylinderMesh();

	// ----- Tripod Legs -----
	float legLength = 1.2f;         // Longer to support wide monitor
	float legAngle = 18.0f;         // Flatter stance (less angle)

	glm::vec3 legScale = glm::vec3(legLength, 0.05f, 0.2f);

	// Left leg
	glm::vec3 leftLegPos = neckPosition + glm::vec3(-legLength * 0.5f - 0.5f, -0.2f, 0.0f);
	SetTransformations(legScale, 0.0f, 0.0f, legAngle, leftLegPos);
	m_basicMeshes->DrawCylinderMesh();

	// Right leg
	glm::vec3 rightLegPos = neckPosition + glm::vec3(legLength * 0.5f + 0.5f, -0.2f, 0.0f);
	SetTransformations(legScale, 0.0f, 0.0f, -legAngle, rightLegPos);
	m_basicMeshes->DrawCylinderMesh();

	// back leg
	glm::vec3 backLegPos = neckPosition + glm::vec3(legLength * 0.5f -0.6f, -0.2f, -0.99f);
	SetTransformations(legScale, 0.0f, 270.0f, legAngle, backLegPos);
	m_basicMeshes->DrawCylinderMesh();
}
   
void SceneManager::DrawMouse() {
	// Base position next to keyboard
	glm::vec3 mouseCenter = glm::vec3(3.0f, 0.0f, 0.6f); // Right side of keyboard

	// --- Mouse Top Shell ---
	glm::vec3 shellScale = glm::vec3(0.6f, 0.35f, 1.0f);
	glm::vec3 shellPos = mouseCenter + glm::vec3(0.0f, 0.15f, 0.0f); // Curved top
	SetTransformations(shellScale, 0.0f, 0.0f, 0.0f, shellPos);
	SetShaderColor(0.04f, 0.04f, 0.04f, 1.0f);
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawHalfSphereMesh();

	// --- Scroll Wheel ---
	glm::vec3 wheelScale = glm::vec3(0.1f, 0.1f, 0.1f);
	glm::vec3 wheelPos = mouseCenter + glm::vec3(0.0f, 0.4f, -0.3f); // Toward front
	SetTransformations(wheelScale, 0.0f, 90.0f, 0.0f, wheelPos); // Face up
	SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawTorusMesh();
}

void SceneManager::DrawHeadphones() {
	// 1. Top headband (horizontal box, left-to-right)
	glm::vec3 headbandScale(1.5f, 0.4f, 0.1f);
	glm::vec3 headbandPos = glm::vec3(2.0f, 0.4f, -4.0f);
	SetTransformations(headbandScale, 0, 0, 0, headbandPos);
	SetShaderMaterial("black_plastic");
	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// 2. Side arms (extend out along Z, attached at ends of headband)
	glm::vec3 armScale(0.12f, 0.4f, 0.8f); // Long in Z
	float armXOffset = headbandScale.x / 2.0f - armScale.x / 2.0f;
	float armZOffset = armScale.z / 2.0f + headbandScale.z / 2.0f; // 0.05f for slight gap

	// Left arm (negative X)
	glm::vec3 leftArmPos = headbandPos + glm::vec3(-armXOffset, 0.0f, armZOffset);
	SetTransformations(armScale, 0, 0, 0, leftArmPos);
	m_basicMeshes->DrawBoxMesh();
	// Right arm (positive X)
	glm::vec3 rightArmPos = headbandPos + glm::vec3(armXOffset, 0.0f, armZOffset);
	SetTransformations(armScale, 0, 0, 0, rightArmPos);
	m_basicMeshes->DrawBoxMesh();

	// 3. Ear speaker
	glm::vec3 domeScale(0.2f, 0.7f, 0.9f);
	float domeZOffset = armScale.z / 2.0f + domeScale.z / 2.0f;
	glm::vec3 leftDomePos = leftArmPos + glm::vec3(0.0f, 0.0f, domeZOffset);
	glm::vec3 rightDomePos = rightArmPos + glm::vec3(-0.0f, 0.0f, domeZOffset);

	SetShaderTexture("filter");

	// Left speaker
	SetTransformations(domeScale, 0, 0, 0, leftDomePos);
	m_basicMeshes->DrawBoxMesh();
	// Right speaker
	SetTransformations(domeScale, 0, 0, 0, rightDomePos);
	m_basicMeshes->DrawBoxMesh();
}

void SceneManager::DrawGameController() {
	// Position to the right of the headphones, scaled down
	glm::vec3 controllerCenter = glm::vec3(4.0f, 0.25f, -4.0f);

	// ==== Main Body ====
	glm::vec3 bodyScale = glm::vec3(1.2f, 0.15f, 0.6f); // Smaller controller base
	glm::vec3 bodyPos = controllerCenter;
	SetTransformations(bodyScale, 0.0f, 0.0f, 0.0f, bodyPos);
	SetShaderColor(0.02f, 0.02f, 0.02f, 1.0f);
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawBoxMesh();

	// ==== Handles (cylinders, angled outward) ====
	glm::vec3 handleScale = glm::vec3(0.15f, 0.1f, 0.5f);
	float handleAngle = 25.0f;
	glm::vec3 leftHandlePos = controllerCenter + glm::vec3(-0.45f, -0.05f, 0.35f);
	glm::vec3 rightHandlePos = controllerCenter + glm::vec3(0.45f, -0.05f, 0.35f);

	SetTransformations(handleScale, 0.0f, 0.0f, handleAngle, leftHandlePos);
	m_basicMeshes->DrawCylinderMesh();
	SetTransformations(handleScale, 0.0f, 0.0f, -handleAngle, rightHandlePos);
	m_basicMeshes->DrawCylinderMesh();

	// ==== Thumbsticks ====
	glm::vec3 stickScale = glm::vec3(0.09f, 0.07f, 0.09f);
	// SWAPPED: leftStickPos is now where dpad was
	glm::vec3 leftStickPos = controllerCenter + glm::vec3(-0.32f, 0.05f, -0.04f);
	glm::vec3 rightStickPos = controllerCenter + glm::vec3(0.2f, 0.05f, 0.18f);

	SetTransformations(stickScale, 0.0f, 0.0f, 0.0f, leftStickPos);
	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	SetTransformations(stickScale, 0.0f, 0.0f, 0.0f, rightStickPos);
	m_basicMeshes->DrawCylinderMesh();

	// ==== Buttons (A, B, X, Y) ====
	glm::vec3 buttonScale = glm::vec3(0.05f, 0.05f, 0.05f);
	glm::vec3 buttonBase = controllerCenter + glm::vec3(0.32f, 0.1f, -0.05f); // Cluster position, on top of body

	// Diamond pattern, close together
	SetShaderColor(0.9f, 0.2f, 0.2f, 1.0f); // Red color for buttons
	SetTransformations(buttonScale, 0.0f, 0.0f, 0.0f, buttonBase + glm::vec3(0.0f, 0.0f, 0.09f)); // A (bottom)
	m_basicMeshes->DrawHalfSphereMesh();

	SetShaderColor(0.2f, 0.9f, 0.2f, 1.0f); // Green color for buttons
	SetTransformations(buttonScale, 0.0f, 0.0f, 0.0f, buttonBase + glm::vec3(0.09f, 0.0f, 0.0f)); // B (right)
	m_basicMeshes->DrawHalfSphereMesh();

	SetShaderColor(0.2f, 0.2f, 0.9f, 1.0f); // Blue color for buttons
	SetTransformations(buttonScale, 0.0f, 0.0f, 0.0f, buttonBase + glm::vec3(-0.09f, 0.0f, 0.0f)); // X (left)
	m_basicMeshes->DrawHalfSphereMesh();

	SetShaderColor(0.9f, 0.9f, 0.2f, 1.0f); // Yellow color for buttons
	SetTransformations(buttonScale, 0.0f, 0.0f, 0.0f, buttonBase + glm::vec3(0.0f, 0.0f, -0.09f)); // Y (top)
	m_basicMeshes->DrawHalfSphereMesh();

	// ==== D-Pad ====
	// SWAPPED: dpadCenter is now where leftStick was
	glm::vec3 dpadCenter = controllerCenter + glm::vec3(-0.18f, 0.09f, 0.18f);
	glm::vec3 dpadScale = glm::vec3(0.06f, 0.02f, 0.18f); // Vertical bar

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);

	// Vertical
	SetTransformations(dpadScale, 0.0f, 0.0f, 0.0f, dpadCenter);
	m_basicMeshes->DrawBoxMesh();

	// Horizontal (cross shape)
	SetTransformations(glm::vec3(0.18f, 0.02f, 0.06f), 0.0f, 0.0f, 0.0f, dpadCenter);
	m_basicMeshes->DrawBoxMesh();
}